<!-- Section: About -->
    <section id="about">
      <div class="container pb-70">
        <div class="section-content">
          <div class="row">
            <div class="col-md-8 col-sm-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">
              <h3 class="text-uppercase mt-0">Welcome To <span class="text-theme-color-2">  LearnPress </span></h3>
              <p class="lead">Here we will groom you to beacome an intellgent student , by giving explaining you through our sessions . </p>
              <div class="row mt-40">
                <div class="col-md-6 wow fadeInUp" data-wow-duration="1s">
                  <div class="mb-sm-30">
                    <img class="img-fullwidth" src="images/about/7.jpg" alt="">
                    <h4 class="letter-space-1 mt-10">Graduation<span class="text-theme-color-2"> Degree</span></h4>
                    <p>Do you want a degree by leraning through our website , start learning today .</p>
                    <a href="#" class="btn btn-sm btn-theme-colored">Read more</a>
                  </div>
                </div>
                <div class="col-md-6 wow fadeInUp" data-wow-duration="1.2s">
                  <div class="mb-sm-30">
                    <img class="img-fullwidth" src="images/about/8.jpg" alt="">
                   
                    <h4 class=" letter-space-1 mt-10">Online<span class="text-theme-color-2"> Learning</span></h4>
                    <p>Do you want to do online leraning by pursuing different courses from KAF Academy.</p>
                    <a href="#" class="btn btn-sm btn-theme-colored">Read more</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
             <div class="p-30 bg-theme-colored mt-10">
                <h3 class="text-white mt-0 mb-10">Get A Free Registration!</h3>
              <!-- Appilication Form Start-->
              <form id="reservation_form" name="reservation_form" class="reservation-form mt-20" method="post" action="#">
                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group mb-20">
                      <input placeholder="Enter Name" type="text" id="reservation_name" name="reservation_name" required="" class="form-control">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group mb-20">
                      <input placeholder="Email" type="text" id="reservation_email" name="reservation_email" class="form-control" required="">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group mb-20">
                      <input placeholder="Phone" type="text" id="reservation_phone" name="reservation_phone" class="form-control" required="">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group mb-20">
                      <div class="styled-select">
                        <select id="person_select" name="person_select" class="form-control" required>
                          <option value="">Courses</option>
                          <option value="1 Person">Software Engineering</option>
                          <option value="2 Person">Computer Traning</option>
                          <option value="3 Person">Development Studies</option>
                          <option value="Family Pack">Chemical Engineering</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group mb-20">
                      <input name="Date" class="form-control required date-picker" type="text" placeholder="Date" aria-required="true" name="date">
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <textarea placeholder="Enter Message" rows="3" class="form-control required" name="form_message" id="form_message" aria-required="true"></textarea>
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group mb-0 mt-10">
                      <input name="form_botcheck" class="form-control" type="hidden" value="">
                      <button type="submit" class="btn btn-colored btn-default text-black btn-lg btn-block" data-loading-text="Please wait..." name="submit">Submit Request</button>
                    </div>
                  </div>
                </div>
              </form>
              <?php
  include "config.php";

  if(isset($_POST['submit'])){
    $name=$_POST['reservation_name'];
    $email=$_POST['reservation_email'];
    $phone=$_POST['reservation_phone'];
    $date=$_POST['date'];
    $message=$_POST['form_message'];
    $course=$_POST['person_select'];

    if($password == $cpassword){
      $sql = "INSERT INTO course (name , email , phone , date , message , course)
              VALUES ('$name','$email','$phone','$date','$message','$course')";

      $result = mysqli_query($conn,$sql);
      if(!$result){
        echo "<script>alert('woops somthing worng')</script>";
      }        

    }
    
  }
?>

              <!-- Application Form End-->

              <!-- Application Form Validation Start-->
              <script type="text/javascript">
                $("#reservation_form").validate({
                  submitHandler: function(form) {
                    var form_btn = $(form).find('button[type="submit"]');
                    var form_result_div = '#form-result';
                    $(form_result_div).remove();
                    form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                    var form_btn_old_msg = form_btn.html();
                    form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                    $(form).ajaxSubmit({
                      dataType:  'json',
                      success: function(data) {
                        if( data.status == 'true' ) {
                          $(form).find('.form-control').val('');
                        }
                        form_btn.prop('disabled', false).html(form_btn_old_msg);
                        $(form_result_div).html(data.message).fadeIn('slow');
                        setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                      }
                    });
                  }
                });
              </script>
              <!-- Application Form Validation Start -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>