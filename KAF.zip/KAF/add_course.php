<?php
require('top.inc.php');
$cid='';
$title='';
$sub_title='';
$price='';
$time='';
$img='';
$discount='';
$duration='';

$image_required='required';
if(isset($_GET['cid']) && $_GET['cid']!=''){
	$image_required='';
	$cid=$_GET['cid'];
	$res=mysqli_query($conn,"select * from mcourse where cid='$cid'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$categories_id=$row['cid'];
		$title=$row['title'];
		$sub_title=$row['sub_title'];
		$price=$row['price'];
		$time=$row['time'];
		$img=$row['img'];
		$discount=$row['discount'];
		$duration=$row['duration'];
	}else{
		header('location:course_data_2.php');
		die();
	}
}

if(isset($_POST['submit'])){
	$cid=$_POST['cid'];
	$title=$_POST['title'];
	$sub_title=$_POST['sub_title'];
	$price=$_POST['price'];
	$time=$_POST['time'];
	$img=$_POST['img'];
	$discount=$_POST['discount'];
	$duration=$_POST['duration'];
	
	$res=mysqli_query($conn,"select * from mcourse where title='$title'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['cid']) && $_GET['cid']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($cid==$getData['cid']){
			
			}else{
				$msg="Product already exist";
			}
		}else{
			$msg="Product already exist";
		}
	}
	
	
	if($_GET['cid']==0){
		if($_FILES['img']['type']!='image/png' && $_FILES['img']['type']!='image/jpg' && $_FILES['img']['type']!='image/jpeg'){
			$msg="Please select only png,jpg and jpeg image formate";
		}
	}else{
		if($_FILES['img']['type']!=''){
				if($_FILES['img']['type']!='image/png' && $_FILES['img']['type']!='image/jpg' && $_FILES['img']['type']!='image/jpeg'){
				$msg="Please select only png,jpg and jpeg image formate";
			}
		}
	}
	
	if($msg==''){
		if(isset($_GET['cid']) && $_GET['cid']!=''){
			if($_FILES['img']['name']!=''){
				$img=rand(111111111,999999999).'_'.$_FILES['img']['name'];
				move_uploaded_file($_FILES['img']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$img);
				$update_sql="update mcourse set cid='$cid',title='$title',sub_title='$sub_title',price='$price',img='$img',time='$time',discount='$discount',duration='$duration' where cid='$cid'";
			}else{
				$update_sql="update mcourse set cid='$cid',title='$title',sub_title='$sub_title',price='$price',img='$img',time='$time',discount='$discount',duration='$duration' where cid='$cid'";
			}
			mysqli_query($conn,$update_sql);
		}else{
			$img=rand(111111111,999999999).'_'.$_FILES['img']['name'];
			move_uploaded_file($_FILES['img']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$img);
			mysqli_query($conn,"insert into mcourse(cid,title,sub_title,price,img,time,discount,duration,status) values('$cid','$title','$sub_title','$price','$img','$time','$discount','$duration',1)");
		}
		header('location:course_data_2.php');
		die();
	}
}
?>
<div class="content pb-0">
            <div class="animated fadeIn">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="card">
                        <div class="card-header"><strong>course</strong><small> Form</small></div>
                        <form method="post" enctype="multipart/form-data">
							<div class="card-body card-block">
							   <div class="form-group">
									<!-- <label for="categories" class=" form-control-label">Categories</label>
									<select class="form-control" name="categories_id">
										<option>Select Category</option
										// $res=mysqli_query($con,"select id,categories from categories order by categories asc");
										// while($row=mysqli_fetch_assoc($res)){
										// 	if($row['id']==$categories_id){
										// 		echo "<option selected value=".$row['id'].">".$row['categories']."</option>";
										// 	}else{
										// 		echo "<option value=".$row['id'].">".$row['categories']."</option>";
										// 	}
											
										// }
									 
									</select> -->
								</div>
                                <div class="form-group">
									<label for="categories" class=" form-control-label">Course ID</label>
									<input type="number" name="cid" placeholder="Enter Course ID" class="form-control" required value="<?php echo $cid?>">
								</div>
								<div class="form-group">
									<label for="categories" class=" form-control-label">Title</label>
									<input type="text" name="title" placeholder="Enter Course Title" class="form-control" required value="<?php echo $title?>">
								</div>
								
								<div class="form-group">
									<label for="categories" class=" form-control-label">sub_title</label>
									<input type="text" name="sub_title" placeholder="Enter Course sub title" class="form-control" required value="<?php echo $sub_title?>">
								</div>
								
								<div class="form-group">
									<label for="categories" class=" form-control-label">Price</label>
									<input type="text" name="price" placeholder="Enter product price" class="form-control" required value="<?php echo $price?>">
								</div>
								
								<div class="form-group">
									<label for="categories" class=" form-control-label">Time</label>
									<input type="text" name="time" placeholder="Enter Time" class="form-control" required value="<?php echo $time?>">
								</div>
								
								<div class="form-group">
									<label for="categories" class=" form-control-label">Image</label>
									<input type="file" name="img" class="form-control" <?php echo  $img?>>
								</div>
								
								<div class="form-group">
									<label for="categories" class=" form-control-label">Discount</label>
									<input type="text" name="discount" placeholder="Enter Discount" class="form-control" required value="<?php echo $discount?>">
								</div>
								
								<div class="form-group">
									<label for="categories" class=" form-control-label">Duration</label>
									<input type="text" name="duration" placeholder="Enter Duration" class="form-control" required value="<?php echo $duration?>">
								</div>
								
							   <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
							   <span id="payment-button-amount">Submit</span>
							   </button>
							   <!-- <div class="field_error"></div> -->
							</div>
						</form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
    