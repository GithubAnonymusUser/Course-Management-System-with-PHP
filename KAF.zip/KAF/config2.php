<?php
// session_start();
$conn=mysqli_connect("localhost","root","","kaf");
define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/KAF/course_image/');
define('SITE_PATH','http://127.0.0.1/KAF/course_image/');

define('PRODUCT_IMAGE_SERVER_PATH',SERVER_PATH.'/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'/');
?>