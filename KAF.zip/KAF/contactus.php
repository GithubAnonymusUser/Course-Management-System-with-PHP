<?php
include('config.php');
if(isset($_POST['s']))
{
  $COUNTRY_ID=$_POST['name'];
  $COUNTRY_NAME=$_POST['email'];
  $COUNTRY_SHORT_NAME=$_POST['sub'];
    $phone=$_POST['phone'];
    $message=$_POST['message'];
    $query="insert into feedback(name,email,sub,phone,message)values('$COUNTRY_ID','$COUNTRY_NAME','$COUNTRY_SHORT_NAME','$phone','$message');";
    
    if(mysqli_query($conn,$query))
    {
      echo '<script>alert("successfully insert")</script>';
      
      
    }
}
?>
<section id="contact" class="">
      <div class="container pt-70 pb-40">
        <div class="section-content">
          <div class="row">
            <div class="col-md-5">
              <h3 class="line-bottom text-uppercase mt-0 mb-30 mt-sm-20">Find Our Location</h3>
              <!-- Google Map HTML Codes -->
              <div 
                data-address="121 King Street, Melbourne Victoria 3000 Australia"
                data-popupstring-id="#popupstring1"
                class="map-canvas autoload-map"
                data-mapstyle="style8"
                data-height="353"
                data-latlng="-37.817314,144.955431"
                data-title="sample title"
                data-zoom="12"
                data-marker="images/map-marker.png">
              </div>
              <div class="map-popupstring hidden" id="popupstring1">
                <div class="text-center">
                  <h3>Health Zone Office</h3>
                  <p>121 King Street, Melbourne Victoria 3000 Australia</p>
                </div>
              </div>
              <!-- Google Map Javascript Codes -->
              <script src="http://maps.google.com/maps/api/js?key=AIzaSyAYWE4mHmR9GyPsHSOVZrSCOOljk8DU9B4"></script>
              <script src="js/google-map-init.js"></script>
            </div>
            <div class="col-md-7">
              <h3 class="line-bottom text-uppercase mt-0 mb-30 mt-sm-20">Send Us a Message</h3> <!-- Contact Form -->
              <form id="contact_form" name="contact_form" class="" action="#" method="post">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group mb-30">
                      <input name="form_name" class="form-control" type="text" placeholder="Enter Name" required="">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group mb-30">
                      <input name="form_email" class="form-control required email" type="email" placeholder="Enter Email">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group mb-30">
                      <input name="form_subject" class="form-control required" type="text" placeholder="Enter Subject">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group mb-30">
                      <input name="form_phone" class="form-control" type="text" placeholder="Enter Phone">
                    </div>
                  </div>
                </div>
                    <div class="form-group mb-15">
                  <textarea name="form_message" class="form-control required" rows="5" placeholder="Enter Message"></textarea>
                </div>
                    <div class="form-group mb-30">
                  <input name="form_botcheck" class="form-control" type="hidden" value="" />
                  <button type="submit" class="btn btn-flat btn-theme-colored text-uppercase mt-20 mb-sm-30 border-left-theme-color-2-4px" data-loading-text="Please wait..." name="submit">Send your message</button>
                  <button type="reset" class="btn btn-flat btn-theme-colored text-uppercase mt-20 mb-sm-30 border-left-theme-color-2-4px">Reset</button>
                </div>
              </form>
              <?php
  include "config.php";

  if(isset($_POST['submit'])){
    $name=$_POST['form_name'];
    $email=$_POST['form_email'];
    $sub=$_POST['form_subject'];
    $phone=$_POST['form_phone'];
    $message=$_POST['form_message'];

      $sql = "INSERT INTO feedback ( name , email , sub , phone , message)
              VALUES ('$name','$email','$sub','$phone','$message')";

      $result = mysqli_query($conn,$sql);
      if(!$result){
        echo "<script>alert('woops somthing worng')</script>";
      }        

    }
    

?>

              <!-- Contact Form Validation-->
              <script type="text/javascript">
                $("#contact_form").validate({
                  submitHandler: function(form) {
                    var form_btn = $(form).find('button[type="submit"]');
                    var form_result_div = '#form-result';
                    $(form_result_div).remove();
                    form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                    var form_btn_old_msg = form_btn.html();
                    form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                    $(form).ajaxSubmit({
                      dataType:  'json',
                      success: function(data) {
                        if( data.status == 'true' ) {
                          $(form).find('.form-control').val('');
                        }
                        form_btn.prop('disabled', false).html(form_btn_old_msg);
                        $(form_result_div).html(data.message).fadeIn('slow');
                        setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                      }
                    });
                  }
                });
              </script>
            </div>
          </div>
        </div>
      </div>
    </section>