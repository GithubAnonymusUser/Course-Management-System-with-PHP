<section id="courses">
      <div class="container pt-70 pb-40">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="mt-0 line-height-1 text-center text-uppercase mb-10 text-black-333">Our <span class="text-theme-color-2"> Courses</span></h2>
             
            </div>
          </div>
        </div>
        <div class="row multi-row-clearfix">
          <div class="col-md-12">
          <div class="owl-carousel-3col owl-nav-top" data-dots="true">
 
<?php
    include('config.php');
   $select_product = mysqli_query($conn, "SELECT * FROM `mcourse`") or die('query failed');
   if(mysqli_num_rows($select_product) > 0){
      while($fetch_product = mysqli_fetch_assoc($select_product)){
?>
   <form method="post" class="box" action="">
                  <div class="item">
                <div class="project mb-30 border-2px">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="image" src="course_image/<?php echo $fetch_product['img'];?>">


                    <div class="hover-link">
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="#"><span><?php echo $fetch_product['price']; ?></span> </a>
                    </div>

                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5"><?php echo $fetch_product['sub_title']; ?></h5>
                    <h4 class="font-weight-700 text-uppercase mt-0"><a href="page-courses-accounting-technologies.html"><?php echo $fetch_product['title']; ?></a></h4>
                   
                    <ul class="list-inline project-conditions text-center m-0 p-10">
                      <li class="current-fund"><strong>Time</strong><?php echo $fetch_product['time']; ?></li>
                      <li class="target-fund"><strong>Discount</strong><?php echo $fetch_product['discount']; ?></li>
                      <li class="remaining-days"><strong>Duration</strong><?php echo $fetch_product['duration']; ?></li>
                    </ul>
                  </div>
                </div>
              </div>
    </form>
<?php
   };
};
?>
            <!-- <div class="owl-carousel-3col owl-nav-top" data-dots="true">
              <div class="item">
                <div class="project mb-30 border-2px">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="images/project/p1.jpg">
                    <div class="hover-link">
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="#"><span>$500</span> </a>
                    </div>
                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5">C Language</h5>
                    <h4 class="font-weight-700 text-uppercase mt-0"><a href="page-courses-accounting-technologies.html">C Language</a></h4>
                   
                    <ul class="list-inline project-conditions text-center m-0 p-10">
                      <li class="current-fund"><strong>Time</strong> June 26</li>
                      <li class="target-fund"><strong>Discount</strong>15%</li>
                      <li class="remaining-days"><strong>Duration</strong>6 Months</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="project mb-30 border-2px">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="images/project/p2.jpg">
                    <div class="hover-link">
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="#"><span>$500</span> </a>
                    </div>
                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5">R & D</h5>
                    <h4 class="font-weight-700 text-uppercase mt-0"><a href="page-courses-accounting-technologies.html">Research & Development</a></h4>
                    
                    <ul class="list-inline project-conditions text-center m-0 p-10">
                      <li class="current-fund"><strong>Time</strong> June 26</li>
                      <li class="target-fund"><strong>Discount</strong>15%</li>
                      <li class="remaining-days"><strong>Duration</strong>6 Months</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="project mb-30 border-2px">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="images/project/p3.jpg">
                    <div class="hover-link">
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="#"><span>$500</span> </a>
                    </div>
                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5">Chemistry</h5>
                    <h4 class="font-weight-700 text-uppercase mt-0"><a href="page-courses-accounting-technologies.html">Chemistry</a></h4>
                  
                    <ul class="list-inline project-conditions text-center m-0 p-10">
                      <li class="current-fund"><strong>Time</strong> June 26</li>
                      <li class="target-fund"><strong>Discount</strong>15%</li>
                      <li class="remaining-days"><strong>Duration</strong>6 Months</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="project mb-30 border-2px">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="images/project/p4.jpg">
                    <div class="hover-link">
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="#"><span>$500</span> </a>
                    </div>
                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5">Basic Mathematics</h5>
                    <h4 class="font-weight-700 text-uppercase mt-0"><a href="page-courses-accounting-technologies.html">BM</a></h4>
                    
                    <ul class="list-inline project-conditions text-center m-0 p-10">
                      <li class="current-fund"><strong>Time</strong> June 26</li>
                      <li class="target-fund"><strong>Discount</strong>15%</li>
                      <li class="remaining-days"><strong>Duration</strong>6 Months</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="project mb-30 border-2px">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="images/project/p5.jpg">
                    <div class="hover-link">
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="#"><span>$500</span> </a>
                    </div>
                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5">Cyber Security</h5>
                    <h4 class="font-weight-700 text-uppercase mt-0"><a href="page-courses-accounting-technologies.html">Ethical Hacking</a></h4>
                    
                    <ul class="list-inline project-conditions text-center m-0 p-10">
                      <li class="current-fund"><strong>Time</strong> June 26</li>
                      <li class="target-fund"><strong>Discount</strong>15%</li>
                      <li class="remaining-days"><strong>Duration</strong>6 Months</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="project mb-30 border-2px">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="images/project/p6.jpg">
                    <div class="hover-link">
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="#"><span>$500</span> </a>
                    </div>
                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5">Data Structures And Algorithum</h5>
                    <h4 class="font-weight-700 text-uppercase mt-0"><a href="page-courses-accounting-technologies.html">DBMS</a></h4>
                   
                    <ul class="list-inline project-conditions text-center m-0 p-10">
                      <li class="current-fund"><strong>Time</strong> June 26</li>
                      <li class="target-fund"><strong>Discount</strong>15%</li>
                      <li class="remaining-days"><strong>Duration</strong>6 Months</li>
                    </ul>
                  </div> -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>