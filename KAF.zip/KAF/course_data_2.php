<!DOCTYPE html>
<html >
  <head>
    
    
    <title>Admin Penal</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    
  </head>
  <body>
    <div class="container-scroller">
      
     
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="index.html"><img src="images/png_logo.png" alt="logo" style="height:62px !important;"/></a>
          <a class="navbar-brand brand-logo-mini" href="index.html"><img src="images/png_logo.png" alt="logo" style="height:62px !important;"/></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          
          
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="index.php">
                <span class="menu-title">Home</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="user.php">
                <span class="menu-title">User</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
           
            <!-- <li class="nav-item">
              <a class="nav-link" href="admin_index.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li> -->
             
            <li class="nav-item">
              <a class="nav-link" href="course_data_2.php">
                <span class="menu-title">Course Manegement</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="course_data.php">
                <span class="menu-title">About Detail</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
             
            <li class="nav-item">
              <a class="nav-link" href="feedback.php">
                <span class="menu-title">Feedback</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-home"></i>
                </span> Course Manegement
              </h3>
              <nav aria-label="breadcrumb">
                <ul class="breadcrumb">
                  <li class="breadcrumb-item active" aria-current="page">
                    <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                  </li>
                </ul>
              </nav>
            </div>
           
            
            
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  
                
              </a>
                    <div class="table-responsive">

                    <?php
                        include('top.inc.php');
                        $query="select * from mcourse";
                        $result=mysqli_query($conn,$query);
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=$_GET['type'];
	if($type=='status'){
		$operation=$_GET['operation'];
		$id=$_GET['cid'];
		if($operation=='active'){
			$status='1';
		}else{
			$status='0';
		}
		$update_status_sql="update mcourse set status='$status' where cid='$id'";
		mysqli_query($conn,$update_status_sql);
	}
	
	if($type=='delete'){
		$id=$_GET['cid'];
		$delete_sql="delete from mcourse where cid='$id'";
		mysqli_query($conn,$delete_sql);
	}
}

$sql="select * from mcourse ";
$res=mysqli_query($conn,$sql);
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Course</h4>
				   <h4 class="box-link"><a href="add_course.php">Add Course</a> </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
							   <th>Course ID</th>
							   <th>Title</th>
							   <th>Sub-Title</th>
							   <th>Image</th>
							   <th>Price</th>
							   <th>Discount</th>
							   <th>Time</th>
                 <th>Duration</th>
							   <th></th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td><?php echo $row['cid']?></td>
							   <td><?php echo $row['title']?></td>
							   <td><?php echo $row['sub_title']?></td>
							   <td><img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['img']?>"/></td>
							   <td><?php echo $row['price']?></td>
							   <td><?php echo $row['discount']?></td>
							   <td><?php echo $row['time']?></td>
                 <td><?php echo $row['duration']?></td>
							   <td>
								<?php
								// if($row['status']==1){
								// 	echo "<span class='badge badge-complete'><a href='?type=status&operation=deactive&cid=".$row['cid']."'>Active</a></span>&nbsp;";
								// }else{
								// 	echo "<span class='badge badge-pending'><a href='?type=status&operation=active&cid=".$row['cid']."'>Deactive</a></span>&nbsp;";
								// }
								echo "<span class='badge badge-edit'><a href='manage_course.php?cid=".$row['cid']."'>Edit</a></span>&nbsp;";
								
								echo "<span class='badge badge-delete'><a href='?type=delete&cid=".$row['cid']."'>Delete</a></span>";
								
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <script src="assets/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>
