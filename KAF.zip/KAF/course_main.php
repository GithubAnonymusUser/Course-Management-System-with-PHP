<?php include "header.php"?>
<?php include "course.php"?>
<?php include "event.php"?>
<?php include "footer.php"?>