<?php
include('config.php');

	$name=$_GET['name'];
	
	$query=mysqli_query($conn, "delete from feedback where name='$name'");
	
	if ($query) 
	{
		echo "<script>alert('You have successfully deleted the data');</script>";
		echo "<script type='text/javascript'>document.location='feedback.php';</script>";
		
	}
	else
	{
		echo"<script>alert('Something Went Wrong. Please try again');</script>";
	}
	
	?>