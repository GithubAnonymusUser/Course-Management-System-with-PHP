<?php
include('config.php');
if(isset($_POST['s']))
{
	$COUNTRY_ID=$_POST['name'];
	$COUNTRY_NAME=$_POST['email'];
	$COUNTRY_SHORT_NAME=$_POST['sub'];
    $phone=$_POST['phone'];
    $message=$_POST['message'];
			$query=mysqli_query($conn, "update  feedback set name='$COUNTRY_ID', email='$COUNTRY_NAME',sub='$COUNTRY_SHORT_NAME', phone='$phone',message='$message' where name='$COUNTRY_ID'");
	
		if ($query) {
			echo "<script>alert('You have successfully update the data');</script>";
			echo "<script type='text/javascript'> document.location = 'feedback.php';
			</script>";
			
		}
		else
		{
			echo "<script>alert('something went wrong. Please try again');</script>";
		}
		
}

?>
<?php
$COUNTRY_ID=$_GET['name'];
$ret=mysqli_query($conn,"select * from  feedback where name='$COUNTRY_ID'");
while ($row=mysqli_fetch_array($ret)) {
?>

<html>
<body>
<form name="add" method="post" action "">
Name<input type="text" name="name"></br>
Email<input type="text" name="email"></br>
Subject<input type="text" name="sub"></br>
Phone<input type="text" name="phone"></br>
Message<input type="text" name="message"></br>
</br>
<?php
}
?>
<input type="submit" name="s" value="update">
</form>
</body>
</html>