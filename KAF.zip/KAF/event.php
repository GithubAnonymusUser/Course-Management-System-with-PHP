<section id="events" class="divider parallax layer-overlay overlay-dark-8" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-70 pb-40">
        <div class="section-title mb-30">
          <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
              <h2 class="mt-0 line-height-1 text-center mb-10 text-white text-uppercase">Upcoming Courses</h2>
            
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="images/about/as7.jpg" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                    
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="images/about/as8.jpg" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                   
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="images/about/as9.jpg" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                    
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 mb-30 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="pricing table-horizontal maxwidth400">
                <div class="row">
                  <div class="col-md-6">
                    <div class="thumb">
                    <img class="img-fullwidth mb-sm-0" src="images/about/as10.jpg" alt="">
                    </div>
                  </div>
                  <div class="col-md-6 p-30 pl-sm-50">
                    <h4 class="mt-0 mb-5"><a href="#" class="text-white">Upcoming Events Title</a></h4>
                    <ul class="list-inline mb-5 text-white">
                      <li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
                      <li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
                    </ul>
                    
                    <a class="text-white font-weight-600" href="#">Read More →</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>