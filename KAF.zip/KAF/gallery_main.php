<?php include "header.php"?>
<?php include "gallery.php"?>
<?php include "footer.php"?>