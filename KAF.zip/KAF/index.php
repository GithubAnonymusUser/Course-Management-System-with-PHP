<!DOCTYPE html>
<html>

<body class="">
<div id="wrapper" class="clearfix">
 
  
  <!-- Header -->
  <?php include "header.php"?>
  
  <!-- Start main-content -->
  <div class="main-content">
    
    <?php include "slider.php"?>

   
    
    
    <!-- Section: About -->
    <?php include "about.php"?>


    <!-- Section: Mission -->
   <?php include "chooseus.php"?>

    <!-- Section: courses -->
    <?php include "course.php"?>


   

    <!-- Section: events -->
    <?php include "event.php"?>
    
    <!-- Gallery Grid 3 -->
    <?php include "gallery.php"?>

   
    
  </div>
  <!-- end main-content -->
  
  
 <?php include "footer.php"?>

 

</body>


</html>