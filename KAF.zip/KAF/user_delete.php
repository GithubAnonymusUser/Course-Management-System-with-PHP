<?php
include('config.php');

	$id=$_GET['id'];
	
	$query=mysqli_query($conn, "delete from users where id='$id'");
	
	if ($query) 
	{
		echo "<script>alert('You have successfully deleted the data');</script>";
		echo "<script type='text/javascript'>document.location='user.php';</script>";
		
	}
	else
	{
		echo"<script>alert('Something Went Wrong. Please try again');</script>";
	}
	
	?>