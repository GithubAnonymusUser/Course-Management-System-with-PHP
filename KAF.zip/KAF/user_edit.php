<?php
include('config.php');
if(isset($_POST['s']))
{
	
	$COUNTRY_ID=$_POST['id'];
	$COUNTRY_NAME=$_POST['username'];
	$COUNTRY_SHORT_NAME=$_POST['email'];
    $phone=$_POST['password'];
		$query=mysqli_query($conn, "update  users set id='$COUNTRY_ID', username='$COUNTRY_NAME',email='$COUNTRY_SHORT_NAME', password='$phone' where id='$COUNTRY_ID'");
	
		if ($query) {
			echo "<script>alert('You have successfully update the data');</script>";
			echo "<script type='text/javascript'> document.location = 'user.php';
			</script>";
			
		}
		else
		{
			echo "<script>alert('something went wrong. Please try again');</script>";
		}
		
}

?>
<?php
$COUNTRY_ID=$_GET['id'];
$ret=mysqli_query($conn,"select * from  users where id='$COUNTRY_ID'");
while ($row=mysqli_fetch_array($ret)) {
?>

<html>
<body>
<form name="add" method="post" action "">
ID<input type="text" name="id"></br>
Username<input type="text" name="username"></br>
Email<input type="text" name="email"></br>
Password<input type="text" name="password"></br>
</br>
<?php
}
?>
<input type="submit" name="s" value="update">
</form>
</body>
</html>